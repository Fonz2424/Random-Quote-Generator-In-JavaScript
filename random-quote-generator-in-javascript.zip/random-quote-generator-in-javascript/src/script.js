const quotesArray=[' "quote number one" ' , 
                   
                   //index 1 of the array
                   ' "quote number two" ' ,                 
                  
                  //index 2 of the array
                   ' "quote number three" ' ,     
                  
                  //index 3 of the array
                   ' "quote number four" ' ,     
                  
                  //index 4 of the array
                   ' "quote number five" ' ,     
                  
                  //index 5 of the array
                   ' "quote number six" '      
 ];
 const quoteEmptyContainer = document.querySelector("#quoteDisplay");
quoteButton.addEventListener('click', displayQuote);

function displayQuote()  {

 let randomGeneratedIndexNumber= Math.floor(Math.random()*quotesArray.length);
  
 quoteDisplay.innerHTML = quotesArray[randomGeneratedIndexNumber];

}







